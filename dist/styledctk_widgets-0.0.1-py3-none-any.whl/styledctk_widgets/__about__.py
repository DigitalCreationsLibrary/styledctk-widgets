# SPDX-FileCopyrightText: 2025-present DigitalCreationsLibrary <aimosta.official@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
