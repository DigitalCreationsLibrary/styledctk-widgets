# CTK_Buttons Templates
 
These are the .py archives of this folder and theirs buttons, respectively:

___
* CTK_Buttons_templates_4_styles.py

![Screenshot_1](https://user-images.githubusercontent.com/97618574/175050413-e106f7a7-e208-4f60-9b00-427e68b8b924.png)
