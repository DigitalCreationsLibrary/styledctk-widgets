# proj-template

[![PyPI - Version](https://img.shields.io/pypi/v/styledctk-widgets.svg)](https://pypi.org/project/pstyledctk-widgets)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/styledctk-widgets.svg)](https://pypi.org/project/styledctk-widgets)

-----

## Table of Contents

- [proj-template](#proj-template)
  - [Table of Contents](#table-of-contents)
  - [Installation](#installation)
  - [License](#license)

## Installation

```console
pip install styledctk-widgets
```

## License

`styledctk-widgets` is distributed under the terms of the following  [License](License) license.
