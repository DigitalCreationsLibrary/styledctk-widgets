# SPDX-FileCopyrightText: 2025-present DigitalCreationsLibrary <aimosta.official@gmail.com>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == "__main__":
    from styledctk_widgets.cli import styledctk_widgets

    sys.exit(styledctk_widgets())
